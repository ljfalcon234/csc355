<?php

$v1 = 9;
$v2 = 4;

$tmp = --$v1;
print "$tmp </br>";

$tmp = --$v1/$v2;
print "$tmp </br>";

$tmp = $v2*3 + 14.5/$v1;
print "$tmp </br>";

$tmp = $v2 + $v1;
print "$tmp </br>";

$tmp = $v1 * $v2;
print "$tmp </br>";

?>