<?php
printf("Your fruit name has been received. We will contact you as soon as possible.")
?>